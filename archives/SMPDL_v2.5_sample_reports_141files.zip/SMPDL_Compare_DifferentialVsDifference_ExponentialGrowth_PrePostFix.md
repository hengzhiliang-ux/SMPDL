# SMPDL 基础对比审计：微分方程 vs 差分方程中的指数增长

> **对比对象**
> - "PreFix" 版本：微分方程 dP/dt = kP, P(0) = P₀，解 P(t) = P₀ e^{kt}（见 `SMP_ProofAnalysis_DifferentialEquation_ExponentialGrowth.md`）
> - "PostFix" 版本：差分方程 P_{n+1} = (1+hk)P_n, P₀ 给定，解 P_n = P₀(1+hk)^n（见 `SMP_ProofAnalysis_DifferenceEquation_ExponentialGrowth.md`）
> 
> **审计日期**：2026-10-13  
> **审计框架**：Göttingen S/M/P × D/L v1.5  
> **总体评价**：⚪ ↔ ⚪ 两个版本在各自公理体系内均正确；差分方程是微分方程的 Euler 离散近似，当 h → 0 且 nh = t 固定时，离散解收敛到连续解。

---

## 1. 版本声明对比

| 维度 | 微分方程（PreFix） | 差分方程（PostFix） |
|---|---|---|
| **主声明** | P(t) = P₀ e^{kt} 是 dP/dt = kP 的解 | P_n = P₀(1+hk)^n 是 P_{n+1} = (1+hk)P_n 的解 |
| **时间变量** | 连续 t ∈ ℝ | 离散 n ∈ ℕ |
| **核心运算** | 导数 dP/dt | 递推 P_{n+1} = rP_n |
| **基础工具** | 实分析、导数、积分、指数函数 | 自然数归纳、等比数列 |
| **解的形式** | 指数函数 e^{kt} | 几何序列 (1+hk)^n |
| **初值** | P(0) = P₀ | P_0 = P₀ |
| **解的存在唯一性** | Picard-Lindelöf 定理 | 递推直接唯一确定序列 |
| **收敛关系** | — | 当 h → 0, nh = t 时，(1+kt/n)^n → e^{kt} |
| **稳定性风险** | 无 | 若 \|1+hk\| > 1 可能发散；Euler 显式格式有条件稳定 |

---

## 2. PreFix 版本 SMPDL 速览（微分方程）

详见 `SMP_ProofAnalysis_DifferentialEquation_ExponentialGrowth.md`。

- **S*D**：自然语言依赖“增长率 ∝ 当前量 → 分离变量 → 积分 → 指数化 → 初值定常数”的语义链。
- **S*L**：术语“解”指可微函数；分离变量时需处理 P = 0。
- **M*D**：ODE + 初值 → 分离变量 → ln|P| = kt + C → P(t) = P₀ e^{kt}。
- **M*L**：逻辑完整；唯一性由 Picard-Lindelöf 保证。
- **P*D / P*L**：Mathlib 提供 `deriv`、`Real.exp`；完整唯一性证明需 ODE 库。

**PreFix 判定**：⚪ 已确认正确（在 ODE 体系内）。

---

## 3. PostFix 版本 SMPDL 六格审计（差分方程）

### 3.1 S*D — 语义依存

| 节点 | 前驱 | 状态 |
|---|---|---|
| 时间步长 h > 0 | 离散化参数 | ✅ |
| 离散时间 n | 自然数索引 | ✅ |
| 递推关系 P_{n+1} = (1+hk)P_n | 差分方程定义 | ✅ |
| 初值 P₀ | 序列起点 | ✅ |
| 数学归纳法 | 证明闭式解 | ✅ |
| 闭式解 P_n = P₀(1+hk)^n | 归纳结论 | ✅ |
| 极限收敛 | (1+kt/n)^n → e^{kt} | ✅（与连续解的联系） |

### 3.2 S*L — 语义逻辑结构

- 差分方程把连续导数替换为“下一时刻 = 当前时刻 × 比例因子”。
- “解”在差分方程中是序列而非函数。
- ⚠️ 自然语言易把离散解与连续解直接等同；必须显式讨论 h → 0 的极限。

### 3.3 M*D — 数学依存

```text
DifferenceEquation_ExponentialGrowth
    │
    ├── Parameters h > 0, k ∈ ℝ, P₀ ∈ ℝ
    │
    ├── Recurrence P_{n+1} = (1 + hk) P_n
    │
    ├── Initial condition P_0 = P₀
    │
    ├── Induction proof
    │       ├── Base: P_0 = P₀ = P₀ (1+hk)^0
    │       └── Step: P_{n+1} = (1+hk) P_n = (1+hk) P₀(1+hk)^n = P₀(1+hk)^{n+1}
    │
    └── Convergence link
            └── If t = nh fixed and h → 0,
                P_n = P₀ (1 + kt/n)^n → P₀ e^{kt}
```

- 依赖关系闭合；收敛到连续解需额外极限定理。

### 3.4 M*L — 数学逻辑结构

| 检查项 | 微分方程 | 差分方程 | 差异说明 |
|---|---|---|---|
| 时间变量 | t ∈ ℝ（连续） | n ∈ ℕ（离散） | 核心差异 |
| 核心运算 | 导数 | 递推 | 基础工具不同 |
| 解的形式 | 指数函数 e^{kt} | 几何序列 (1+hk)^n | 形式不同 |
| 证明工具 | 分离变量、积分、唯一性定理 | 数学归纳法 | 策略不同 |
| 解的唯一性 | Picard-Lindelöf | 递推直接唯一确定 | 机制不同 |
| 与另一版本联系 | 极限 h → 0 | 极限 h → 0 | 收敛关系 |

### 3.5 P*D / P*L — 编程层

- 微分方程在 Lean 中用 `ℝ → ℝ` 函数 + `deriv` 表达。
- 差分方程在 Lean 中用 `ℕ → ℝ` 序列 + `Nat.rec` / `induction` 表达。
- 两个版本的解形式不同，但可通过极限定理建立联系。

---

## 4. 跨层映射检查（PostFix vs PreFix）

| 映射 | 微分（PreFix） | 差分（PostFix） | 变化 |
|---|---|---|---|
| S → M | “增长率 ∝ P” → P'(t) = kP(t) | “每步增长 (1+hk) 倍” → P_{n+1} = (1+hk)P_n | 核心语义操作改变 |
| M → P | `deriv P t = k * P t` | `P (n+1) = (1+h*k) * P n` | 形式化表达不同 |
| S ↔ P | 分离变量 → 积分/指数 | 递推 → `Nat.rec` / `induction` | 语义-代码桥梁不同 |
| S ↔ S | P(t) = P₀ e^{kt} | P_n = P₀(1+hk)^n | 解的形式不同 |
| M ↔ M | 连续分析、导数 | 离散归纳、等比数列 | 数学基础不同 |
| 极限联系 | P(t) | P_{t/h} → P(t) as h → 0 | 统一桥梁 |

**跨层结论**：两个版本的 S/M/P 层各自自洽，层间映射关系不同；差异根源于连续 vs 离散的基础假设。两者通过 Euler 离散化 + 极限 h → 0 建立联系。

---

## 5. 判定：PostFix 是否为真？

| 维度 | 微分（PreFix） | 差分（PostFix） |
|---|---|---|
| 自然语言声明真实性 | ⚪ 真 | ⚪ 真 |
| 证明正确性 | ⚪ 正确 | ⚪ 正确 |
| 形式化验证 | ✅ Mathlib `deriv` / `Real.exp` | ✅ `Nat.rec` / `induction` |
| 与已知数学兼容性 | ✅ 与 ODE 理论兼容 | ✅ 与差分方程 / 数值分析兼容 |
| 与另一版本一致性 | 极限 h → 0 时一致 | 极限 h → 0 时一致 |
| 稳定性/额外风险 | 无 | Euler 显式格式可能发散或振荡 |

**SMPDL 判定（PostFix）**：⚪ **低风险 / 已确认正确**。差分方程版本不是对微分方程版本的“修复”，而是“同一增长模型的离散近似表述”。

---

## 6. 变化类型归类

- **变化方式**：**基础假设迁移**（foundation shift）+ **离散化近似**，而非证明错误修复。
- **核心假设差异**：
  - 微分方程：时间是连续实数；变化率用导数描述；解是实函数。
  - 差分方程：时间是离散自然数；变化用递推描述；解是实序列。
- **证明骨架相似性**：两者都从“增长率 ∝ 当前量”出发，通过某种“累积”得到解；一个用积分/指数，一个用递推/等比。
- **SMPDL 同构标签建议**：`S-ISO / M-BISIM / P-BISIM`。
  - S-ISO：结论语义相同（指数增长模型）。
  - M-BISIM：都使用“比例增长”结构，但连续用导数/积分，离散用递推/归纳。
  - P-BISIM：形式化类型不同（`ℝ → ℝ` 函数 vs `ℕ → ℝ` 序列）。
- **关键 lesson**：从连续到离散的迁移不是符号替换；必须显式处理时间变量、解的类型、存在唯一性机制与收敛条件。

---

## 7. 人类科学家可执行的验证动作

1. **B 岗位**：核对 Elaydi 差分方程教材与 Boyce-DiPrima ODE 教材中指数增长模型的对比。
2. **C 岗位**：对 k = 1, P₀ = 1 计算若干 h 下的离散解，并与连续解 e^t 比较，观察 h → 0 时的收敛。
3. **D 岗位**：检查两份报告的 `AxiomaticBase` 字段是否已显式声明（`DifferentialEquation` vs `DifferenceEquation`）。
4. **E 岗位**：在 Lean 4 中分别用 `deriv` 与 `Nat.rec` 形式化两个解，并验证 (1+kt/n)^n → e^{kt}。
5. **F 岗位**：生成两份报告的 PDF 并对比“解”一词在函数与序列两种语境中的使用。

---

## 8. 文献引用纪律检查

| 引用对象 | 真实性 | 支持性 | 说明 |
|---|---|---|---|
| Boyce-DiPrima, *Elementary Differential Equations* | ✅ | ✅ | 微分方程标准教材。 |
| Elaydi, *An Introduction to Difference Equations* | ✅ | ✅ | 差分方程标准教材。 |
| Atkinson, *Numerical Analysis* | ✅ | ✅ | Euler 方法来源。 |
| Picard-Lindelöf 唯一性定理 | ✅ | ✅ | ODE 解唯一性。 |
| Mathlib `deriv` / `Real.exp` / `Nat.rec` | ✅ | ✅ | 形式化层参考。 |

**核查结论**：所有引用对象真实存在，支持方向与本对比报告一致。

---

## 9. 署名与许可

**Göttingen S/M/P × D/L · v1.5 · CAMPANASILVAE · fecit · MMXXVI · CC BY-NC-SA 4.0**

搬运、改写或教学引用请注明来源与本页面链接。
