# SMPDL 基础对比审计：集合论 vs 类型论中的 n + 0 = n

> **对比对象**
> - "PreFix" 版本：集合论中 n + 0 = n（见 `SMP_ProofAnalysis_SetTheory_NatPlusZero.md`）
> - "PostFix" 版本：类型论中 n + 0 = n（见 `SMP_ProofAnalysis_TypeTheory_NatPlusZero.md`）
> 
> **审计日期**：2026-10-13  
> **审计框架**：Göttingen S/M/P × D/L v1.5  
> **总体评价**：⚪ ↔ ⚪ 两个版本在各自公理体系内均正确；结论相同（n + 0 = n），但证明结构、基础假设与“等式”的含义不同。

---

## 1. 版本声明对比

| 维度 | 集合论（PreFix） | 类型论（PostFix） |
|---|---|---|
| **主声明** | ∀n ∈ ℕ, n + 0 = n | ∀n : ℕ, n + 0 = n |
| **基础框架** | ZFC / Peano 算术 + 集合论递归定理 | Martin-Löf / 归纳类型论 |
| **自然数 ℕ** | 集合（Peano 结构 / von Neumann 序数） | 归纳类型，构造子 0 和 succ |
| **加法定义方式** | 对每个 m，用递归定理定义 h_m，m + n := h_m(n) | 对第一个参数递归定义的函数 add |
| **n + 0 = n 的证明** | 由加法定义直接得出（h_n(0) = n） | 需对 n 做归纳证明 |
| **核心工具** | 递归定理、函数外延性 | 归纳类型原理、identity type |
| **等式 = 的含义** | 集合论外延相等 | 命题等式（identity type / Eq） |
| **形式化证明长度** | `rfl`（定义等式） | `induction n; simp [ih]` |
| **形式化依赖库** | Mathlib `Nat.add`（底层类型论） | Lean 4 `Nat` / Coq `nat` |

---

## 2. PreFix 版本 SMPDL 速览（集合论）

详见 `SMP_ProofAnalysis_SetTheory_NatPlusZero.md`。

- **S*D**：自然语言依赖“ℕ → 递归定理 → 加法定义 → 等式”的语义链。
- **S*L**：量词清晰；但“由定义即得”容易掩盖递归定理的基础作用。
- **M*D**：Recursion Theorem → unique h_m → m + n := h_m(n) → h_n(0) = n。
- **M*L**：逻辑完整；结论由定义直接得出。
- **P*D / P*L**：Lean 中可用 `rfl` 完成，但底层已非集合论，而是类型论的 β-归约。

**PreFix 判定**：⚪ 已确认正确（在集合论体系内）。

---

## 3. PostFix 版本 SMPDL 六格审计（类型论）

### 3.1 S*D — 语义依存

| 节点 | 前驱 | 状态 |
|---|---|---|
| ℕ 为归纳类型 | 类型论基础 | ✅ |
| 构造子 0 和 succ | ℕ 的归纳定义 | ✅ |
| 加法 add 递归定义 | 对第一个参数递归 | ✅ |
| 0 + n = n | add 的 base case | ✅ |
| (succ m) + n = succ (m + n) | add 的 step case | ✅ |
| 按 n 归纳 | ℕ 的归纳原理 | ✅ |
| n + 0 = n | 归纳结论 | ✅ |

### 3.2 S*L — 语义逻辑结构

- 类型论版本需显式使用 ℕ 的归纳原理。
- 关键语义差异：集合论中等式是外延相等；类型论中等式是命题等式（identity type / Eq），需要构造证明项。
- ⚠️ 两种基础下“n + 0 = n”的符号相同，但证明负担不同。

### 3.3 M*D — 数学依存

```text
TypeTheory_NatPlusZero
    │
    ├── Type theory foundation
    │
    ├── Inductive type ℕ with 0 and succ
    │
    ├── Recursively defined addition
    │       ├── 0 + n = n
    │       └── (succ m) + n = succ (m + n)
    │
    ├── Identity type Eq
    │
    └── Proof by induction
            ├── Base: 0 + 0 = 0
            └── Step: k + 0 = k ⇒ succ k + 0 = succ (k + 0) = succ k
```

- 依赖关系闭合；证明依赖 ℕ 的归纳结构。

### 3.4 M*L — 数学逻辑结构

| 检查项 | 集合论 | 类型论 | 差异说明 |
|---|---|---|---|
| ℕ 的基础 | 集合 / Peano 结构 | 归纳类型 | 核心差异 |
| 加法定义 | 递归定理给出 h_m | 对第一个参数递归 | 结构相似但表述不同 |
| n + 0 = n 的证明 | 定义直接得出 | 需对 n 归纳 | **关键差异** |
| 等式 | 外延 = | identity type Eq | 语义不同 |
| 证明对象 | 元数学证明 | 显式 proof term | 类型论中证明是对象 |

### 3.5 P*D / P*L — 编程层

- 两个版本在 Lean 中最终都产生 `n + 0 = n` 的证明项。
- 集合论风格的“直接由定义”在 Lean 中表现为 `rfl`，但前提是 Lean 的 `Nat.add` 定义方式恰好让 `n + 0` 可定义归约为 `n`。
- 类型论风格的“归纳证明”在 Lean 中表现为 `induction n <;> simp [ih]`。
- **重要**：Lean 中 `n + 0 = n` 实际上是定义等式（因为 `Nat.add` 对第一个参数递归），所以可用 `rfl`；但在类型论元语言中，这一等式的证明结构仍是“对 n 的结构归纳”。这里存在“具体定义选择”与“一般类型论语义”的张力。

---

## 4. 跨层映射检查（PostFix vs PreFix）

| 映射 | 集合论（PreFix） | 类型论（PostFix） | 变化 |
|---|---|---|---|
| S → M | “由定义即得” → 递归定理 | “对 n 归纳” → 归纳类型原理 | 核心证明策略不同 |
| M → P | `rfl`（若定义选择合适） | `induction` / `Nat.rec` | 形式化策略不同 |
| S ↔ P | 定义等式 → `rfl` | 归纳证明 → `induction` | 语义-代码桥梁不同 |
| S ↔ S | n + 0 = n | n + 0 = n | 结论语义相同 |
| M ↔ M | 函数外延性 + 递归定理 | 归纳类型 + identity type | 数学基础不同 |
| 证明对象 | 元数学证明 | 显式 proof term | P 层本质差异 |

**跨层结论**：两个版本的结论一致，但 S/M/P 层的证明结构不同。集合论依赖外延相等与递归定理；类型论依赖归纳类型、identity type 与结构归纳。

---

## 5. 判定：PostFix 是否为真？

| 维度 | 集合论（PreFix） | 类型论（PostFix） |
|---|---|---|
| 自然语言声明真实性 | ⚪ 真 | ⚪ 真 |
| 证明正确性 | ⚪ 正确 | ⚪ 正确 |
| 形式化验证 | ✅ `rfl`（依赖具体定义） | ✅ `induction` |
| 与已知数学兼容性 | ✅ 与 ZFC / Peano 兼容 | ✅ 与 Martin-Löf / CoC 兼容 |
| 结论一致性 | n + 0 = n | n + 0 = n | 相同 |
| 基础强度 | 递归定理 / 外延性 | 归纳类型 / identity type | 不同 |

**SMPDL 判定（PostFix）**：⚪ **低风险 / 已确认正确**。类型论版本不是对集合论版本的“修复”，而是“在同一命题下用不同基础给出证明结构”。

---

## 6. 变化类型归类

- **变化方式**：**基础假设迁移**（foundation shift），而非证明错误修复。
- **核心假设差异**：
  - 集合论：ℕ 是集合（Peano 结构 / von Neumann 序数）；等式是外延相等；加法由递归定理唯一确定。
  - 类型论：ℕ 是归纳类型；等式是 identity type；加法由结构递归定义；证明是显式 proof term。
- **证明骨架相似性**：两者都使用递归/归纳定义加法，但 n + 0 = n 在集合论中是定义的 base case，在类型论中需要一次完整的归纳证明（取决于加法参数顺序）。
- **SMPDL 同构标签建议**：`S-ISO / M-BISIM / P-BISIM`。
  - S-ISO：结论与符号相同（n + 0 = n）。
  - M-BISIM：都使用递归/归纳，但等式的数学本质不同（外延相等 vs identity type）。
  - P-BISIM：形式化代码可能相似（都可用 `rfl` 在 Lean 中完成），但底层 proof term 的结构不同。
- **关键 lesson**：同一等式在不同基础下可能有不同的证明负担与证明对象。SMPDL 的任务是显式标注 `AxiomaticBase` 并检查等式在不同基础下的语义。

---

## 7. 人类科学家可执行的验证动作

1. **B 岗位**：核对集合论语义下递归定理与函数外延性在自然数加法定义中的作用。
2. **C 岗位**：核对 Martin-Löf 类型论中 ℕ 的归纳类型定义与 identity type 的构造规则。
3. **D 岗位**：检查两份报告的 `AxiomaticBase` 字段是否已显式声明（`SetTheory` vs `TypeTheory`）。
4. **E 岗位**：在 Lean 4 中分别用 `rfl` 和 `induction` 两种策略证明 `n + 0 = n`，观察生成的 proof term（`by?` / `#print`）。
5. **F 岗位**：生成两份报告的 PDF 并对比“=”与“证明”两术语的使用范围。

---

## 8. 文献引用纪律检查

| 引用对象 | 真实性 | 支持性 | 说明 |
|---|---|---|---|
| Peano 算术 / 集合论递归定理 | ✅ | ✅ | 集合论版本来源。 |
| Martin-Löf 类型论 / 归纳类型 | ✅ | ✅ | 类型论版本来源。 |
| Identity type / Eq | ✅ | ✅ | 类型论中等式基础。 |
| Mathlib / Lean 4 `Nat` | ✅ | ✅ | 形式化层参考。 |

**核查结论**：所有引用对象真实存在，支持方向与本对比报告一致。

---

## 9. 署名与许可

**Göttingen S/M/P × D/L · v1.5 · CAMPANASILVAE · fecit · MMXXVI · CC BY-NC-SA 4.0**

搬运、改写或教学引用请注明来源与本页面链接。
